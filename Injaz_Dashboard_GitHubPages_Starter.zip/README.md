
# Injaz Dashboard Starter Project

This is a starter project for the Injaz Dashboard, ready for deployment on GitHub Pages.

## Usage

1. Clone this repository
2. Open `index.html` in browser, or deploy to GitHub Pages / Netlify
3. Modify HTML/CSS/JS as needed
